package com.example.myapplication.helper;

import android.app.Activity;
import android.graphics.Color;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.codemybrainsout.ratingdialog.RatingDialog;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.material.snackbar.Snackbar;
import com.kulmis.myquiz.R;

public class Utils {

    public static AdRequest adRequest;
    public static InterstitialAd interstitial;


    public static void loadAd(Activity activity) {
        try {
            adRequest = new AdRequest.Builder().build();
            InterstitialAd.load(activity, activity.getResources().getString(R.string.admob_interstitial),
                    adRequest, new InterstitialAdLoadCallback() {
                        @Override
                        public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                            interstitial = interstitialAd;
                            interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                                @Override
                                public void onAdShowedFullScreenContent() {

                                }

                                @Override
                                public void onAdDismissedFullScreenContent() {
                                    super.onAdDismissedFullScreenContent();
                                    loadAd(activity);
                                }
                            });
                        }

                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                            interstitial = null;
                        }
                    });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void displayInterstitial(Activity activity) {
        if (interstitial != null) {
            interstitial.show(activity);
        } else {
            Log.d("TAG", "The interstitial ad wasn't ready yet.");
        }
    }

    public static void setSnackBar(final Activity activity, String message) {
        final Snackbar snackbar = Snackbar.make(activity.findViewById(android.R.id.content),
                message, Snackbar.LENGTH_INDEFINITE);
        snackbar.setAction(activity.getString(R.string.ok), view -> snackbar.dismiss());
        snackbar.setActionTextColor(Color.RED);
        View snackBarView = snackbar.getView();
        TextView textView = snackBarView.findViewById(com.google.android.material.R.id.snackbar_text);
        textView.setMaxLines(5);
        snackbar.show();
    }

    public static void setSnackBarRetry(final Activity activity, String message) {
        final Snackbar snackbar = Snackbar.make(activity.findViewById(android.R.id.content),
                message, Snackbar.LENGTH_INDEFINITE);
        snackbar.setAction(activity.getString(R.string.retry), view -> activity.recreate());
        snackbar.setActionTextColor(Color.RED);
        View snackbarView = snackbar.getView();
        TextView textView = snackbarView.findViewById(com.google.android.material.R.id.snackbar_text);
        textView.setMaxLines(15);
        snackbar.show();
    }

    public static void smartRating(final Activity activity) {
        final RatingDialog ratingDialog = new RatingDialog.Builder(activity)
                .icon(activity.getDrawable(R.drawable.smart_rating))
                .threshold(3)
                .title(activity.getString(R.string.rate_dialog_title))
                .titleTextColor(R.color.black)
                .positiveButtonText(activity.getString(R.string.rate_dialog_cancel))
                .negativeButtonText(activity.getString(R.string.rate_dialog_no))
                .positiveButtonTextColor(R.color.purple_700)
                .negativeButtonTextColor(R.color.grey_500)
                .formTitle(activity.getString(R.string.rate_dialog_suggest))
                .formHint(activity.getString(R.string.rate_dialog_suggestion))
                .formSubmitText(activity.getString(R.string.rate_dialog_submit))
                .formCancelText(activity.getString(R.string.rate_form_cancel))
                .playstoreUrl("http://play.google.com/store/apps/details?id=" + activity.getPackageName())
                .onRatingBarFormSumbit(new RatingDialog.Builder.RatingDialogFormListener() {
                    @Override
                    public void onFormSubmitted(String feedback) {
                        // Save Suggestion
                        /*DatabaseReference reference = FirebaseDatabase.getInstance().getReference();
                        reference.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                HashMap<String, Object> hashMapw = new HashMap<>();
                                hashMapw.put("message", feedback);
                                hashMapw.put("username", userName);
                                hashMapw.put("date_time", internetDate);
                                hashMapw.put("email", userEmail);

                                String key = reference.push().getKey();
                                reference.child("Down Rated").child(Objects.requireNonNull(key))
                                        .updateChildren(hashMapw).addOnCompleteListener(task -> {
                                    Toast.makeText(getApplicationContext(), "Submitted, Thanks!", Toast.LENGTH_SHORT).show();
                                });

                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });*/
                    }
                })
                .build();

        ratingDialog.show();
    }
}
