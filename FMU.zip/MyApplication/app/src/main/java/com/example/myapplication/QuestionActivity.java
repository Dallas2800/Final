package com.example.myapplication;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Vibrator;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import com.airbnb.lottie.LottieAnimationView;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.material.card.MaterialCardView;
import com.example.myapplication.helper.Constant;
import com.example.myapplication.helper.DBHelper;
import com.example.myapplication.helper.Utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Random;

import nl.dionsegijn.konfetti.KonfettiView;
import nl.dionsegijn.konfetti.models.Shape;
import nl.dionsegijn.konfetti.models.Size;

public class QuestionActivity extends AppCompatActivity {

    private int Total_Questions;
    private List<Question> question_List;
    private int question_id;
    private int Answered_Questions = 0;
    private Question currentQ;
    private TextView txtQuestion;
    private TextView question_number;
    private TextView button1;
    private TextView button2;
    private TextView button3;
    private MaterialCardView cardViewButton1;
    private MaterialCardView cardViewButton2;
    private MaterialCardView cardViewButton3;
    private MaterialCardView cardViewDefault;
    private MediaPlayer correct_sound;
    private MediaPlayer incorrect_sound;
    private KonfettiView sprinkleView, sprinkleView2;
    private AlertDialog completedDialog, resetDialog;
    private View completedDialogView;
    private SharedPreferences qidSave;
    private SharedPreferences dayNightSave;
    private View aboutDialogView;
    private AlertDialog aboutDialog;
    private AdView mAdView;
    private Menu menu;
    private LottieAnimationView lottieAnimationView;
    private Toolbar toolbar;
    private AdRequest adRequest;
    private String dayNightState;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_question);
            initMethod();
            setSupportActionBar(toolbar);
            Objects.requireNonNull(getSupportActionBar()).setTitle(Constant.ACTIONBAR_TITLE);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            Utils.loadAd(QuestionActivity.this);
            mAdView.loadAd(adRequest);
            if (Constant.night.equals(dayNightState))
                getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            cardViewButton1.setOnClickListener(v -> button1.performClick());
            cardViewButton2.setOnClickListener(v -> button2.performClick());
            cardViewButton3.setOnClickListener(v -> button3.performClick());
            question_number.setText(question_id + 1 + getString(R.string.slash) + Total_Questions);
            button1.setOnClickListener(v -> getAnswer(button1.getText().toString().trim()));
            button2.setOnClickListener(v -> getAnswer(button2.getText().toString().trim()));
            button3.setOnClickListener(v -> getAnswer(button3.getText().toString().trim()));
            SharedPreferences sharedFinish = getSharedPreferences(Constant.SHARED_FINISH, MODE_PRIVATE);
            if (sharedFinish.getString(Constant.SHARED_FINISH, "").equals(Constant.finished))
                GameCompleteMethod();
            new Handler().postDelayed(this::enableAllFields, 2100);
            setQuestionView();
            hideOrShow();
            disableAllFields();

        } catch (Exception e) {
            Utils.setSnackBarRetry(QuestionActivity.this, e.getLocalizedMessage());
        }
    }

    private void initMethod() {
        MobileAds.initialize(this, initializationStatus -> {
        });
        toolbar = findViewById(R.id.toolbar);
        mAdView = findViewById(R.id.adView);
        adRequest = new AdRequest.Builder().build();
        qidSave = getSharedPreferences(Constant.QID_SAVE, MODE_PRIVATE);
        dayNightSave = getSharedPreferences(Constant.DAY_NIGHT_SAVE, MODE_PRIVATE);
        dayNightState = dayNightSave.getString(Constant.DAY_NIGHT_SAVE, Constant.day);
        question_id = qidSave.getInt(Constant.QID_SAVE, 0);
        DBHelper db = new DBHelper(this);
        question_List = db.getAllQuestions();
        currentQ = question_List.get(question_id);
        if (Constant.ShuffleQuestions == 1) Collections.shuffle(question_List);
        Total_Questions = question_List.size() - 1;
        question_number = findViewById(R.id.qnumber);
        lottieAnimationView = findViewById(R.id.lottie_yes);
        sprinkleView = findViewById(R.id.viewKonfitti);
        sprinkleView2 = findViewById(R.id.viewKonfitti2);
        cardViewDefault = findViewById(R.id.crd_default);
        cardViewButton1 = findViewById(R.id.crd_button1);
        cardViewButton2 = findViewById(R.id.crd_button2);
        cardViewButton3 = findViewById(R.id.crd_button3);
        correct_sound = MediaPlayer.create(QuestionActivity.this, R.raw.correct_sound);
        incorrect_sound = MediaPlayer.create(QuestionActivity.this, R.raw.incorrect_sound);
        txtQuestion = findViewById(R.id.txtQuestion);
        button1 = findViewById(R.id.button1);
        button2 = findViewById(R.id.button2);
        button3 = findViewById(R.id.button3);
        dialogsInit();
        rateInit();
    }

    private void rateInit() {
        SharedPreferences preferencesRate = getSharedPreferences(Constant.SHARED_RATE, MODE_PRIVATE);
        int i = preferencesRate.getInt(Constant.SHARED_RATE, 0);
        i = i + 1;
        preferencesRate.edit().putInt(Constant.SHARED_RATE, i).apply();
        if (i == 6 || i == 25) {
            Utils.smartRating(QuestionActivity.this);
        }
    }

    @SuppressLint("InflateParams")
    private void dialogsInit() {
        LayoutInflater factory = LayoutInflater.from(this);
        LayoutInflater factory2 = LayoutInflater.from(this);
        LayoutInflater factory3 = LayoutInflater.from(this);
        completedDialogView = factory.inflate(R.layout.dialog_completed, null);
        completedDialog = new AlertDialog.Builder(this).setCancelable(false).create();
        View resetDialogView = factory2.inflate(R.layout.dialog_reset, null);
        resetDialog = new AlertDialog.Builder(this).setCancelable(false).create();
        aboutDialogView = factory3.inflate(R.layout.dialog_about, null);
        aboutDialog = new AlertDialog.Builder(this).setCancelable(true).create();
        completedDialog.setView(completedDialogView);
        resetDialog.setView(resetDialogView);
        aboutDialog.setView(aboutDialogView);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        this.menu = menu;
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        String sd = dayNightSave.getString(Constant.DAY_NIGHT_SAVE, Constant.day);
        switch (sd) {
            case "day":
                menu.getItem(2).setIcon(ContextCompat.getDrawable(this, R.drawable.ic_day));
                break;
            case "night":
                menu.getItem(2).setIcon(ContextCompat.getDrawable(this, R.drawable.ic_night));
                break;
        }
        return super.onPrepareOptionsMenu(menu);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == R.id.menu_high) {
            String sd = dayNightSave.getString(Constant.DAY_NIGHT_SAVE, Constant.day);
            switch (sd) {
                case "day":
                    dayNightSave.edit().putString(Constant.DAY_NIGHT_SAVE, Constant.night).apply();
                    //AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                    getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                    menu.getItem(2).setIcon(ContextCompat.getDrawable(this, R.drawable.ic_night));
                    break;
                case "night":
                    dayNightSave.edit().putString(Constant.DAY_NIGHT_SAVE, Constant.day).apply();
                    //AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                    getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                    menu.getItem(2).setIcon(ContextCompat.getDrawable(this, R.drawable.ic_day));
                    break;
            }
        } else if (item.getItemId() == R.id.menu_about) {
            TextView textView = aboutDialogView.findViewById(R.id.tv_version);
            TextView textViewEmail = aboutDialogView.findViewById(R.id.tv_email);
            if (!Constant.ContactEmail.equals(Constant.YOUR_CONTACT_EMAIL))
                textViewEmail.setText(getString(R.string.contact) + "\n" + Constant.ContactEmail);
            textView.setText(getString(R.string.version) + BuildConfig.VERSION_NAME + "]");
            aboutDialogView.findViewById(R.id.crd_about).setOnClickListener(v -> {
                if (!Constant.developer_page.equals(getString(R.string.your_developer_page)))
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(Constant.developer_page)));
                    } catch (android.content.ActivityNotFoundException anfe) {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(Constant.developer_page)));
                    }
                aboutDialog.dismiss();
            });
            Objects.requireNonNull(aboutDialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            aboutDialog.show();
        } else if (item.getItemId() == R.id.menu_rate) {
            final String appPackageName = getPackageName(); // getPackageName() from Context or Activity object
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.market) + appPackageName)));
            } catch (android.content.ActivityNotFoundException anfe) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.play_store_suffix) + appPackageName)));
            }
        } else if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    private void sprinkleMethod() {
        sprinkleView.build().addColors(Color.YELLOW, Color.GREEN, Color.MAGENTA).setDirection(0.0, 359.0).setSpeed(1f, 5f).setFadeOutEnabled(true).setTimeToLive(2000L).addShapes(Shape.Square.INSTANCE, Shape.Circle.INSTANCE).addSizes(new Size(12, 5)).setPosition(-50f, sprinkleView.getWidth() + 50f, -200f, -200f).streamFor(300, 2000L);
        sprinkleView2.build().addColors(Color.YELLOW, Color.GREEN, Color.MAGENTA).setDirection(0.0, 359.0).setSpeed(1f, 5f).setFadeOutEnabled(true).setTimeToLive(2000L).addShapes(Shape.Square.INSTANCE, Shape.Circle.INSTANCE).addSizes(new Size(12, 5)).setPosition(-50f, sprinkleView.getWidth() + 50f, -200f, -200f).streamFor(300, 2000L);
    }

    @SuppressLint("SetTextI18n")
    private void hideOrShow() {
        button1.setVisibility(View.INVISIBLE);
        button2.setVisibility(View.INVISIBLE);
        button3.setVisibility(View.INVISIBLE);
        txtQuestion.setVisibility(View.INVISIBLE);

        new Handler().postDelayed(() -> {
            Animation i = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.leave);
            button1.startAnimation(i);
            button2.startAnimation(i);
            button3.startAnimation(i);
            txtQuestion.startAnimation(i);
            button1.setVisibility(View.VISIBLE);
            button2.setVisibility(View.VISIBLE);
            button3.setVisibility(View.VISIBLE);
            txtQuestion.setVisibility(View.VISIBLE);
        }, 2000);
    }

    @SuppressLint("SetTextI18n")
    public void getAnswer(final String AnswerString) {
        try {
            if (currentQ.getTRUE_ANSWER().equalsIgnoreCase(AnswerString)) {
                // If Right Answer
                Answered_Questions += 1;
                lottieAnimationView.playAnimation();
                qidSave.edit().putInt(Constant.QID_SAVE, question_id).apply();
                buttonIsPressed();
                disableAllFields();
                new Handler().postDelayed(() -> correct_sound.start(), 500);

                if (currentQ.getTRUE_ANSWER().equalsIgnoreCase(button1.getText().toString())) {
                    button1.setTextColor(Color.WHITE);
                    cardViewButton1.setCardBackgroundColor(getResources().getColor(R.color.correct_answer));
                } else if (currentQ.getTRUE_ANSWER().equalsIgnoreCase(button2.getText().toString())) {
                    button2.setTextColor(Color.WHITE);
                    cardViewButton2.setCardBackgroundColor(getResources().getColor(R.color.correct_answer));
                } else if (currentQ.getTRUE_ANSWER().equalsIgnoreCase(button3.getText().toString())) {
                    button3.setTextColor(Color.WHITE);
                    cardViewButton3.setCardBackgroundColor(getResources().getColor(R.color.correct_answer));
                }

            } else {
                // If the Wrong Answer

                currentQ.finish();
                disableAllFields();
                buttonIsPressed();
                correct_sound.stop();
                incorrect_sound.start();

                // Make the Correct Answer Green
                if (Constant.ShowCorrectAnswer == 1) {
                    if (currentQ.getTRUE_ANSWER().equalsIgnoreCase(button1.getText().toString())) {
                        button1.setTextColor(Color.WHITE);
                        cardViewButton1.setCardBackgroundColor(getResources().getColor(R.color.correct_answer));
                    } else if (currentQ.getTRUE_ANSWER().equalsIgnoreCase(button2.getText().toString())) {
                        button2.setTextColor(Color.WHITE);
                        cardViewButton2.setCardBackgroundColor(getResources().getColor(R.color.correct_answer));
                    } else if (currentQ.getTRUE_ANSWER().equalsIgnoreCase(button3.getText().toString())) {
                        button3.setTextColor(Color.WHITE);
                        cardViewButton3.setCardBackgroundColor(getResources().getColor(R.color.correct_answer));
                    }
                }
                Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                Objects.requireNonNull(vibrator).vibrate(100);

                // Make the Wrong Answer RED
                Animation shake = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.shake);
                ArrayList<TextView> buttonList = new ArrayList<>();
                buttonList.add(button1);
                buttonList.add(button2);
                buttonList.add(button3);
                for (TextView button : buttonList) {
                    if (button.getText().equals(AnswerString)) {
                        button.setBackgroundColor(getResources().getColor(R.color.wrong_answer));
                        button.startAnimation(shake);
                        break;
                    }
                }
                new Handler().postDelayed(this::resultMethod, Constant.ShowResult);
            }
            if (question_id < question_List.size() - 1) {
                disableAllFields();
                int LENGTH = Constant.BetweenQuestions;
                new Handler().postDelayed(() -> {
                    if (currentQ.getTRUE_ANSWER().equalsIgnoreCase(AnswerString)) {
                        currentQ = question_List.get(question_id);
                        clearColor();
                        disableAllFields();

                        new Handler().postDelayed(this::setQuestionView, 1000);
                        new Handler().postDelayed(this::enableAllFields, 2100);

                        cardViewButton1.setCardBackgroundColor(cardViewDefault.getCardBackgroundColor());
                        cardViewButton2.setCardBackgroundColor(cardViewDefault.getCardBackgroundColor());
                        cardViewButton3.setCardBackgroundColor(cardViewDefault.getCardBackgroundColor());
                        TextView textViewDefault = findViewById(R.id.button1_default);
                        button1.setTextColor(textViewDefault.getTextColors());
                        button2.setTextColor(textViewDefault.getTextColors());
                        button3.setTextColor(textViewDefault.getTextColors());

                        Animation i = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.enter);
                        button1.startAnimation(i);
                        button2.startAnimation(i);
                        button3.startAnimation(i);
                        new Handler().postDelayed(() -> {
                            button1.setVisibility(View.INVISIBLE);
                            button2.setVisibility(View.INVISIBLE);
                            button3.setVisibility(View.INVISIBLE);
                        }, 1000);

                        question_number.setText(question_id + 1 + getString(R.string.slash) + (question_List.size() - 1));
                        if (question_id != question_List.size()) {
                            hideOrShow();
                        }

                    }
                }, LENGTH);
            } else {
                new Handler().postDelayed(() -> {
                    correct_sound.stop();
                    incorrect_sound.stop();
                    disableAllFields();
                    if (currentQ.getTRUE_ANSWER().equalsIgnoreCase(AnswerString)) {
                        SharedPreferences sharedFinish = getSharedPreferences(Constant.SHARED_FINISH, MODE_PRIVATE);
                        sharedFinish.edit().putString(Constant.SHARED_FINISH, Constant.finished).apply();
                        GameCompleteMethod();
                        sprinkleMethod();
                    }
                }, Constant.BetweenQuestions);
            }
        } catch (Exception e) {
            Utils.setSnackBar(QuestionActivity.this, e.getLocalizedMessage());
        }
    }

    private void buttonIsPressed() {
        if (button1.isPressed()) {
            cardViewButton1.setCardBackgroundColor(getResources().getColor(R.color.button_press));
            cardViewButton1.setStrokeColor(getResources().getColor(R.color.button_press));
            button1.setTextColor(Color.WHITE);
        } else if (button2.isPressed()) {
            cardViewButton2.setCardBackgroundColor(getResources().getColor(R.color.button_press));
            cardViewButton2.setStrokeColor(getResources().getColor(R.color.button_press));
            button2.setTextColor(Color.WHITE);
        } else if (button3.isPressed()) {
            cardViewButton3.setCardBackgroundColor(getResources().getColor(R.color.button_press));
            cardViewButton3.setStrokeColor(getResources().getColor(R.color.button_press));
            button3.setTextColor(Color.WHITE);
        }
    }

    private void clearColor() {
        cardViewButton1.setStrokeColor(getResources().getColor(R.color.theme_color));
        cardViewButton2.setStrokeColor(getResources().getColor(R.color.theme_color));
        cardViewButton3.setStrokeColor(getResources().getColor(R.color.theme_color));
    }


    @SuppressLint("SetTextI18n")
    private void GameCompleteMethod() {
        question_number.setText((question_List.size() - 1) + getString(R.string.slash) + (question_List.size() - 1));
        completedDialogView.findViewById(R.id.img_replay_comp).setOnClickListener(v -> showDialogReset());
        Objects.requireNonNull(completedDialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        completedDialog.show();
    }

    private void showDialogReset() {
        new AlertDialog.Builder(QuestionActivity.this)
                .setTitle(getString(R.string.warning))
                .setMessage(getString(R.string.reset_message))
                .setPositiveButton(getString(R.string.yes), (dialog, which) -> {
                    SharedPreferences sharedFinish = getSharedPreferences(Constant.SHARED_FINISH, MODE_PRIVATE);
                    sharedFinish.edit().putString(Constant.SHARED_FINISH, Constant.reset).apply();
                    qidSave.edit().putInt(Constant.QID_SAVE, 0).apply();
                    resetDialog.dismiss();
                    completedDialog.dismiss();
                    recreate();
                    Toast.makeText(getApplicationContext(), getString(R.string.reset_successful), Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton(getString(R.string.no), null)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }

    private void setQuestionView() {
        txtQuestion.setText(currentQ.getQUESTION());
        String[] b = {
                currentQ.getTRUE_ANSWER().trim().substring(0, 1).toUpperCase() + currentQ.getTRUE_ANSWER().trim().substring(1).toLowerCase(),
                currentQ.getFALSE1().trim().substring(0, 1).toUpperCase() + currentQ.getFALSE1().trim().substring(1).toLowerCase(),
                currentQ.getFALSE2().trim().substring(0, 1).toUpperCase() + currentQ.getFALSE2().trim().substring(1).toLowerCase()
        };
        if (Constant.ShuffleOptions == 1) Collections.shuffle(Arrays.asList(b));
        button1.setText(b[0]);
        button2.setText(b[1]);
        button3.setText(b[2]);
        question_id++;
    }

    private void disableAllFields() {
        ArrayList<TextView> buttonList = new ArrayList<>();
        buttonList.add(button1);
        buttonList.add(button2);
        buttonList.add(button3);
        for (TextView button : buttonList) {
            button.setEnabled(false);
        }
        ArrayList<CardView> cardList = new ArrayList<>();
        cardList.add(cardViewButton1);
        cardList.add(cardViewButton2);
        cardList.add(cardViewButton3);
        for (CardView cardView : cardList) {
            cardView.setEnabled(false);
        }
    }

    private void enableAllFields() {
        ArrayList<TextView> buttonList = new ArrayList<>();
        buttonList.add(button1);
        buttonList.add(button2);
        buttonList.add(button3);
        for (TextView button : buttonList) {
            button.setEnabled(true);
        }
        ArrayList<CardView> cardList = new ArrayList<>();
        cardList.add(cardViewButton1);
        cardList.add(cardViewButton2);
        cardList.add(cardViewButton3);
        for (CardView cardView : cardList) {
            cardView.setEnabled(true);
        }
    }

    @SuppressLint("SetTextI18n")
    private void resultMethod() {
        Utils.displayInterstitial(QuestionActivity.this);
        disableAllFields();
        LayoutInflater factory = LayoutInflater.from(this);
        final View deleteDialogView = factory.inflate(R.layout.activity_resulty_question, null);
        final AlertDialog deleteDialog = new AlertDialog.Builder(this).setCancelable(false).create();
        deleteDialog.setView(deleteDialogView);
        LinearLayout layoutAdd = deleteDialogView.findViewById(R.id.banner_container_resulty);
        if (mAdView.getParent() != null) {
            ((ViewGroup) mAdView.getParent()).removeView(mAdView); // <- fix
        }
        if (layoutAdd != null) {
            layoutAdd.addView(mAdView);
        }
        TextView textViewWelDone = deleteDialogView.findViewById(R.id.tv_weldone);
        String[] welDoneMessage;
        if (Answered_Questions > 0) {
            welDoneMessage = getResources().getStringArray(R.array.more_than);
        } else {
            welDoneMessage = getResources().getStringArray(R.array.less_than);
        }
        int randomIndex = new Random().nextInt(welDoneMessage.length);
        String randomName = welDoneMessage[randomIndex];
        textViewWelDone.setText(randomName);
        TextView yy = deleteDialogView.findViewById(R.id.tv_answered_result);
        yy.setText("" + Answered_Questions);
        deleteDialogView.findViewById(R.id.img_replay_result).setOnClickListener(v -> {
            try {
                Toast.makeText(getApplicationContext(), getString(R.string.replay), Toast.LENGTH_SHORT).show();
                recreate();
                deleteDialog.dismiss();

            } catch (Exception e) {
                Utils.setSnackBarRetry(QuestionActivity.this, e.getLocalizedMessage());
            }
        });
        Objects.requireNonNull(deleteDialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        if (!this.isFinishing()) {
            new Handler().postDelayed(deleteDialog::show, 1000);
        } else {
            recreate();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mAdView != null) {
            mAdView.destroy();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (question_id > Total_Questions) {
            GameCompleteMethod();
        }
    }
}