package com.example.myapplication.helper;

public class Constant {

    public static final String ACTIONBAR_TITLE = "My Quiz";
    public static int ShuffleQuestions = 0;                     // 0 = Don't Shuffle Questions, 1 = Shuffle Questions
    public static int ShuffleOptions = 1;                       // 0 = Don't Shuffle Options, 1 = Shuffle Options
    public static int ShowCorrectAnswer = 1;                    // 0 = Don't Show Correct Answer, 1 = Show
    public static int ShowResult = 2000;                        // Show Result Activity in 2sec
    public static int BetweenQuestions = 3000;                  // Wait before the next question in 3sec

    public static final String ONESIGNAL_APP_ID = "YOUR_ONESIGNAL_APP_ID";
    public static String developer_page = "YOUR_PLAY_STORE_PAGE_LINK";
    public static String ContactEmail = "YOUR_CONTACT_EMAIL";




    // DON'T CHANG BELOW FIELDS
    public static final String SHARED_FINISH = "SHARED_FINISH";
    public static final String YOUR_CONTACT_EMAIL = "YOUR_CONTACT_EMAIL";
    public static final String DAY_NIGHT_SAVE = "DAY_NIGHT_SAVE";
    public static final String SHARED_RATE = "SHARED_RATE";
    public static final String QID_SAVE = "QID_SAVE";
    public static final String DATABASE_NAME = "my_quiz";
    public static final int DATABASE_VERSION = 1;
    public static final String QUESTION = "question";
    public static final String OPTA = "opa";
    public static final String OPTB = "opb";
    public static final String OPTC = "opc";
    public static final String QUEST = "quest";
    public static final String QID = "qid";
    public static String day = "day";
    public static String night = "night";
    public static String finished = "finished";
    public static String reset = "reset";
}
