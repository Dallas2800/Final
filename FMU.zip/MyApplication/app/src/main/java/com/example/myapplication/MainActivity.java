package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.example.myapplication.helper.Constant;

import com.google.android.material.navigation.NavigationView;
import com.ismaeldivita.chipnavigation.ChipNavigationBar;

public class MainActivity extends AppCompatActivity {

    // Login e Registro
    DrawerLayout drawerLayout;
    NavigationView navigationView;
    ActionBarDrawerToggle drawerToggle;

    private ChipNavigationBar chipNavigationBar;
    private Fragment fragment = null;

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(drawerToggle.onOptionsItemSelected(item)){
            return true;
        }
        return super.onOptionsItemSelected(item);
    }



    @SuppressLint("MissingInflatedId") // solução temporaria para erro das linhas 47 e 48
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences dayNightSave = getSharedPreferences(Constant.DAY_NIGHT_SAVE, MODE_PRIVATE);
        String dayNightState = dayNightSave.getString(Constant.DAY_NIGHT_SAVE, Constant.day);
        if (Constant.night.equals(dayNightState))
            getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        goToQuestion();
    }

    private void goToQuestion() {
        new Handler().postDelayed(() -> {
            Intent intent = new Intent(MainActivity.this, QuestionActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        }, 2500);
    }



        chipNavigationBar = findViewById(R.id.chipNavigation);
        chipNavigationBar.setItemSelected(R.id.home, true);
        getSupportFragmentManager().beginTransaction().replace(R.id.container, new HomeFragment()).commit();

        chipNavigationBar.setOnItemSelectedListener(new ChipNavigationBar.OnItemSelectedListener() {
            @Override
            public void onItemSelected(int i) {
                switch (i) {
                    case R.id.Homes:
                        fragment = new HomesFragment();
                        break;
                    case R.id.Quiz:
                        fragment = new QuizFragment();
                        break;
                    case R.id.Estude:
                        fragment = new EstudeFragment();
                        break;

                }

                if (fragment != null) {
                    getSupportFragmentManager().beginTransaction().replace(R.id.container, fragment).commit();
                }
            }
        });
    }


        //Login&Registro

        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        drawerToggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.open, R.string.close);
        drawerLayout.addDrawerListener(drawerToggle);
        drawerToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.home: {
                        Toast.makeText(MainActivity.this, "Inicio Selecionado", Toast.LENGTH_SHORT).show();
                        break;
                    }
                    case R.id.contact: {
                        Toast.makeText(MainActivity.this, "Contato Selecionado", Toast.LENGTH_SHORT).show();
                        break;
                    }
                    case R.id.gallery: {
                        Toast.makeText(MainActivity.this, "Imagens Selecionado", Toast.LENGTH_SHORT).show();
                        break;
                    }
                    case R.id.about: {
                        Toast.makeText(MainActivity.this, "Sobre Selecionado", Toast.LENGTH_SHORT).show();
                        break;
                    }
                    case R.id.Login: {
                        Toast.makeText(MainActivity.this, "Login Selecionado", Toast.LENGTH_SHORT).show();
                        break;
                    }
                    case R.id.share: {
                        Toast.makeText(MainActivity.this, "Compartilhe Selecionado", Toast.LENGTH_SHORT).show();
                        break;
                    }
                    case R.id.rate_us: {
                        Toast.makeText(MainActivity.this, "Nota Selecionado", Toast.LENGTH_SHORT).show();
                        break;
                    }
                }
                return false;
            }
        });



        }




}
