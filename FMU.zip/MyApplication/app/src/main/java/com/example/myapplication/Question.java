package com.example.myapplication;

import android.app.Activity;

public class Question extends Activity {

    private int ID;
    private String QUESTION;
    private String TRUE_ANSWER;
    private String FALSE1;
    private String FALSE2;


    public Question() {
        ID = 0;
        QUESTION = "";
        TRUE_ANSWER = "";
        FALSE1 = "";
        FALSE2 = "";
    }

    public Question(String Question, String True_Answer, String False1, String False2) {
        QUESTION = Question;
        TRUE_ANSWER = True_Answer;
        FALSE1 = False1;
        FALSE2 = False2;
    }

    public int getID() {
        return ID;
    }

    public String getQUESTION() {
        return QUESTION;
    }

    public String getTRUE_ANSWER() {
        return TRUE_ANSWER;
    }

    public String getFALSE1() {
        return FALSE1;
    }

    public String getFALSE2() {
        return FALSE2;
    }

    public void setID(int id) {
        ID = id;
    }

    public void setQUESTION(String qUESTION) {
        QUESTION = qUESTION;
    }

    public void setTRUE_ANSWER(String oPTA) {
        TRUE_ANSWER = oPTA;
    }

    public void setFALSE1(String oPTB) {
        FALSE1 = oPTB;
    }

    public void setFALSE2(String oPTC) {
        FALSE2 = oPTC;
    }

}
