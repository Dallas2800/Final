package com.example.myapplication.helper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.kulmis.myquiz.Question;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {
    public static final String TABLE_QUEST = Constant.QUEST;
    public static final String KEY_ID = Constant.QID;
    public static final String KEY_QUES = Constant.QUESTION;
    public static final String KEY_OPTA = Constant.OPTA;
    public static final String KEY_OPTB = Constant.OPTB;
    public static final String KEY_OPTC = Constant.OPTC;
    private static final int DATABASE_VERSION = Constant.DATABASE_VERSION;
    private static final String DATABASE_NAME = Constant.DATABASE_NAME;
    public SQLiteDatabase dbase;
    Context context;
    String sql;
    ContentValues values;

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        dbase = db;
        sql = "CREATE TABLE IF NOT EXISTS " + TABLE_QUEST + " ( "
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + KEY_QUES +
                " TEXT, " + KEY_OPTA + " TEXT, "
                + KEY_OPTB + " TEXT, " + KEY_OPTC + " TEXT)";
        db.execSQL(sql);
        addQuestion();
    }

    private void addQuestion() {
        this.addQuestion(new Question("Teste ?", "1", "2", "3"));
        this.addQuestion(new Question("Teste1 ?", "1", "2", "3"));
        this.addQuestion(new Question("Teste2 ?", "1", "2", "3"));
        this.addQuestion(new Question("Teste3 ?", "1", "2", "3"));
        this.addQuestion(new Question("Teste4 ?", "1", "2", "3"));
        this.addQuestion(new Question("Teste5 ?", "1", "2", "3"));
        this.addQuestion(new Question("Teste6 ?", "1", "2", "3"));




        this.addQuestion(new Question("Don't_Delete_This_Line", "OK", "Ok", "OK"));

        // END
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        // Drop older table if existed
        //db.execSQL("DROP TABLE IF EXISTS " + TABLE_QUEST);
        // Create tables again
        //onCreate(db);
    }

    public void addQuestion(Question quest) {
        values = new ContentValues();
        values.put(KEY_QUES, quest.getQUESTION());
        values.put(KEY_OPTA, quest.getTRUE_ANSWER());
        values.put(KEY_OPTB, quest.getFALSE1());
        values.put(KEY_OPTC, quest.getFALSE2());
        dbase.insert(TABLE_QUEST, null, values);
    }

    public List<Question> getAllQuestions() {
        List<Question> quesList = new ArrayList<>();
        dbase = this.getReadableDatabase();
        Cursor cursor = dbase.query(TABLE_QUEST, new String[]{"*"}, null, null, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                Question quest = new Question();
                quest.setID(cursor.getInt(0));
                quest.setQUESTION(cursor.getString(1));
                quest.setTRUE_ANSWER(cursor.getString(2));
                quest.setFALSE1(cursor.getString(3));
                quest.setFALSE2(cursor.getString(4));
                quesList.add(quest);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return quesList;
    }
}
